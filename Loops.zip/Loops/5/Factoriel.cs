﻿// Write a program that calculates  n! / k!  for given  n  and  k  (1 < k < n < 100).
// Use only one loop.
using System;
class Factoriel
    {
    static void Main()
    {
        int N = int.Parse(Console.ReadLine());
        int K = int.Parse(Console.ReadLine());
        long result = 1;
        for (int i = N; i < N-K; i--)
        {
            result *= i;
        }
        Console.WriteLine(result);
    }
    }

