﻿//Current Date and Time
using System;
  class CurrentDateAndTime
    {
        static void Main(string[] args)
        {
            Console.WriteLine(DateTime.Now);
        }
    }

