﻿// Print Мy Name
using System;
    class PrintMyName
    {
        static void Main()
        {
            Console.Write("Таня" + " ");
            Console.WriteLine("Янева");            
        }
    }
