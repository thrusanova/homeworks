﻿//Write a program to print the numbers  1, 101 and 1001 , each at a separate line.
using System;
    class PrintNumbers
    {
        static void Main()
        {
            int a = 1;
            int b = 101;
            int c = 1001;
            Console.WriteLine(a);
            Console.WriteLine(b);
            Console.WriteLine(c);
        }
    }

