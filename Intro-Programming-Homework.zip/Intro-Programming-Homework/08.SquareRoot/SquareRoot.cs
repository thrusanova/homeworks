﻿//Create a console application that calculates and prints the square root of the number  12345 .
using System;
    class SquareRoot
    {
        static void Main()
        {
            int number = 12345;
            Console.WriteLine(Math.Sqrt(number));
        }
    }

