﻿using System;

namespace ConsoleApplication1
{
    class PrintMyName
    {
        static void Main()
        {
            Console.WriteLine("My name is Tanya.");
        }
    }
}
