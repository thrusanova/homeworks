﻿//Reformat C# Code
using System;
    class HorribleCode
    {
        static void Main()
        {
            Console.WriteLine("Hi,I am horribly formatted problem");
            Console.WriteLine("Number and squares :");
            for (int i = 0; i < 10;i ++ )
            {
                Console.WriteLine(i+ "-->" +i * i);
            }
        }
    }
    

