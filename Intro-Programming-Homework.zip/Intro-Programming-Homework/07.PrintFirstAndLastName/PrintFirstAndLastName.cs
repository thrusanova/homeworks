﻿//Create console application that prints your first and last name, each at a separate line.
using System;
class PrintFirstAndLastName
    {
        static void Main()
        {
            Console.WriteLine("Таня");
            Console.WriteLine("Янева");
        }
    }

