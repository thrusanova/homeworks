﻿//Write a program that enters 5 numbers (given in a single line, separated by a space), calculates and prints their sum
using System;
   class SumFiveNumbers
    {
        static void Main()
        {
            string [] numbers = Console.ReadLine().Split(' ');
            double a = double.Parse(numbers[0]);
            double b = double.Parse(numbers[1]);
            double c = double.Parse(numbers[2]);
            double d = double.Parse(numbers[3]);
            double e = double.Parse(numbers[4]);
            Console.WriteLine(a+b+c+d+e);
        }
    }

