﻿//Write a program that converts a number in the range [0…999] to words, corresponding to the English pronunciation.
using System;
    class NumberAsWords
    {
          static string UppercaseFirst(string s)
    {
	if (string.IsNullOrEmpty(s))
	{
	    return string.Empty;
	}
	char[] a = s.ToCharArray();
	a[0] = char.ToUpper(a[0]);
    return new string(a);
     }
        static void Main()
        {
            int number = int.Parse(Console.ReadLine());
            Console.WriteLine(UppercaseFirst(NumberToWords(number)));
        }
        public static string NumberToWords(int number)
        {
            if (number == 0)
                return "zero";
            
            string words = "";

            if ((number / 100) > 0)
            {
                words += NumberToWords(number / 100) + " hundred ";
                number %= 100;
            }

            if (number > 0)
            {
                if (words != "")
                    words += "and ";

                var unitsDigits = new[] { "zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen" };
                var tensDigits = new[] { "zero", "ten", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety" };

                if (number < 20)
                    words += unitsDigits[number];
                else
                {
                    words += tensDigits[number / 10];
                    if ((number % 10) > 0)
                        words += " " + unitsDigits[number % 10];
                }
            }
            return words;
        }
    }

