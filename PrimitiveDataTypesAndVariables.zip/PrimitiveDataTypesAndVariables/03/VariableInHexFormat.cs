﻿using System;
    class VariableInHexFormat
    {
        static void Main()
        {
            int number = 0xFE;
            Console.WriteLine(number);
        }
    }

