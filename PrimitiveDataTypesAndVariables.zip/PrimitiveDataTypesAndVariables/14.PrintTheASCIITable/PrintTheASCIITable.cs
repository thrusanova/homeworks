﻿
using System;
    class PrintASCII
    {
   static void Main(string[] args)
        {
            for (int i = 0; i <= 255; i++)
            {
                Console.Write((char)i);
            }
   Console.WriteLine();
        }

    }
