﻿//Declare five variables choosing for each of them the most appropriate of the types  byte, sbyte, short, ushort, int, uint, long, ulong  to represent the following values:  52130, -115, 4825932, 97, -10000 .
// Choose a large enough type for each number to ensure it will fit in it. Try to compile the code

using System;
class DeclareVariables
{
    static void Main()
    {
        sbyte firstNumber = -115;
        byte secondNumber = 97;
        ushort thrirdNumber = 52130;
        short fourthNumber = -10000;
        int fifthnumber = 4825932;
        Console.WriteLine(firstNumber);
        Console.WriteLine(secondNumber);
        Console.WriteLine(thrirdNumber);
        Console.WriteLine(fourthNumber);
        Console.WriteLine(fifthnumber);
    }
}

